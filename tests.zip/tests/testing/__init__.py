"""
Tests for MGE V2 Acceptance Testing module
"""
