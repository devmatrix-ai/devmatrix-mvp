"""Performance tests for RAG system."""
