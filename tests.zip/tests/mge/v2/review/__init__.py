"""
Tests for MGE V2 Review Module
"""
