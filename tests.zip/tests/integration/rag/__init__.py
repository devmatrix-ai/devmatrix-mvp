"""Integration tests for RAG system."""
