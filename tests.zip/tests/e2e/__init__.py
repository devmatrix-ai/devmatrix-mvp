"""
E2E Tests for DevMatrix MGE V2 Pipeline

End-to-end tests validating complete pipeline execution with checkpoint/recovery support.
"""
