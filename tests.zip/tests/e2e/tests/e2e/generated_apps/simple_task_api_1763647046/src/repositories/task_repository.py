"""
{{ entity.name }} Repository

Data access layer for {{ entity.table_name }} table.
"""
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from uuid import UUID
from typing import Optional, List
from src.models.entities import {{ entity.name }}Entity
from src.models.schemas import {{ entity.name }}Create, {{ entity.name }}Update
import structlog

logger = structlog.get_logger(__name__)


class {{ entity.name }}Repository:
    """Data access layer for {{ entity.name }}."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, {{ entity.snake_name }}_data: {{ entity.name }}Create) -> {{ entity.name }}Entity:
        """
        Create new {{ entity.snake_name }}.

        Args:
            {{ entity.snake_name }}_data: {{ entity.name }} creation data

        Returns:
            Created {{ entity.snake_name }} entity
        """
        {{ entity.snake_name }} = {{ entity.name }}Entity(**{{ entity.snake_name }}_data.model_dump())
        self.db.add({{ entity.snake_name }})
        await self.db.flush()
        await self.db.refresh({{ entity.snake_name }})

        logger.info("{{ entity.snake_name }}_created", {{ entity.snake_name }}_id=str({{ entity.snake_name }}.id))
        return {{ entity.snake_name }}

    async def get(self, {{ entity.snake_name }}_id: UUID) -> Optional[{{ entity.name }}Entity]:
        """
        Get {{ entity.snake_name }} by ID.

        Args:
            {{ entity.snake_name }}_id: {{ entity.name }} UUID

        Returns:
            {{ entity.name }} entity or None if not found
        """
        result = await self.db.execute(
            select({{ entity.name }}Entity).where({{ entity.name }}Entity.id == {{ entity.snake_name }}_id)
        )
        return result.scalar_one_or_none()

    async def list(self, skip: int = 0, limit: int = 100) -> List[{{ entity.name }}Entity]:
        """
        List {{ entity.table_name }} with pagination.

        Args:
            skip: Number of records to skip
            limit: Maximum number of records to return

        Returns:
            List of {{ entity.snake_name }} entities
        """
        result = await self.db.execute(
            select({{ entity.name }}Entity).offset(skip).limit(limit)
        )
        return result.scalars().all()

    async def count(self) -> int:
        """
        Count total {{ entity.table_name }}.

        Returns:
            Total count of {{ entity.table_name }}
        """
        result = await self.db.execute(
            select({{ entity.name }}Entity)
        )
        return len(result.scalars().all())

    async def update(
        self, {{ entity.snake_name }}_id: UUID, {{ entity.snake_name }}_data: {{ entity.name }}Update
    ) -> Optional[{{ entity.name }}Entity]:
        """
        Update {{ entity.snake_name }}.

        Args:
            {{ entity.snake_name }}_id: {{ entity.name }} UUID
            {{ entity.snake_name }}_data: Update data

        Returns:
            Updated {{ entity.snake_name }} entity or None if not found
        """
        # Get existing {{ entity.snake_name }}
        {{ entity.snake_name }} = await self.get({{ entity.snake_name }}_id)
        if not {{ entity.snake_name }}:
            return None

        # Update only provided fields
        update_data = {{ entity.snake_name }}_data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr({{ entity.snake_name }}, key, value)

        await self.db.flush()
        await self.db.refresh({{ entity.snake_name }})

        logger.info("{{ entity.snake_name }}_updated", {{ entity.snake_name }}_id=str({{ entity.snake_name }}_id))
        return {{ entity.snake_name }}

    async def delete(self, {{ entity.snake_name }}_id: UUID) -> bool:
        """
        Delete {{ entity.snake_name }}.

        Args:
            {{ entity.snake_name }}_id: {{ entity.name }} UUID

        Returns:
            True if deleted, False if not found
        """
        result = await self.db.execute(
            delete({{ entity.name }}Entity).where({{ entity.name }}Entity.id == {{ entity.snake_name }}_id)
        )

        deleted = result.rowcount > 0
        if deleted:
            logger.info("{{ entity.snake_name }}_deleted", {{ entity.snake_name }}_id=str({{ entity.snake_name }}_id))

        return deleted