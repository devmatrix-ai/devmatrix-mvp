# FastAPI Application

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100+-green.svg)](https://fastapi.tiangolo.com/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-14+-336791.svg)](https://www.postgresql.org/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

A production-ready FastAPI application for managing products, customers, shopping carts, and orders with comprehensive monitoring, logging, and testing capabilities.

## 🚀 Features

### Core Functionality
- **Product Management**: Create, read, update, and deactivate products with inventory tracking
- **Customer Management**: Register and manage customer profiles with registration tracking
- **Shopping Cart**: Create and manage shopping carts with automatic reuse of open carts
- **Order Processing**: Complete order lifecycle management with payment status tracking
- **Health Monitoring**: System health checks and availability monitoring

### Technical Features
- ✅ Async/await support for high-performance operations
- ✅ PostgreSQL with SQLAlchemy ORM for data persistence
- ✅ Pydantic v2 for robust data validation
- ✅ Alembic for database schema versioning and migrations
- ✅ Structured logging with structlog
- ✅ Prometheus metrics and monitoring
- ✅ Comprehensive test coverage with pytest
- ✅ Docker and Docker Compose support
- ✅ Automatic API documentation (Swagger UI & ReDoc)
- ✅ Environment-based configuration

## 📋 Tech Stack

| Component | Technology |
|-----------|-----------|
| **Framework** | FastAPI 0.100+ |
| **Web Server** | Uvicorn |
| **Database** | PostgreSQL 14+ |
| **ORM** | SQLAlchemy 2.0+ (async) |
| **Validation** | Pydantic v2 |
| **Migrations** | Alembic |
| **Logging** | structlog |
| **Monitoring** | Prometheus |
| **Testing** | pytest |
| **Containerization** | Docker & Docker Compose |
| **Python** | 3.11+ |

## 📦 Prerequisites

Before you begin, ensure you have the following installed:

- **Python 3.11** or higher
- **PostgreSQL 14** or higher
- **Docker** and **Docker Compose** (optional, for containerized deployment)
- **pip** (Python package manager)
- **git** (for version control)

## 🔧 Installation

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/fastapi-application.git
cd fastapi-application
```

### 2. Create a Virtual Environment

```bash
python3.11 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Set Up Environment Variables

Copy the example environment file and configure it:

```bash
cp .env.example .env
```

Edit `.env` with your configuration (see [Configuration](#⚙️-configuration) section).

### 5. Initialize the Database

```bash
# Run migrations
alembic upgrade head

# Or use the Makefile
make migrate
```

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the project root with the following variables:

```env
# Application
APP_NAME=FastAPI Application
APP_VERSION=1.0.0
DEBUG=False
LOG_LEVEL=INFO

# Database
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/fastapi_db
DATABASE_ECHO=False

# Server
HOST=0.0.0.0
PORT=8000
WORKERS=4

# Security (optional)
SECRET_KEY=your-secret-key-here
ALGORITHM=HS256

# Monitoring
PROMETHEUS_ENABLED=True
METRICS_PORT=9090

# CORS (if needed)
ALLOWED_ORIGINS=["http://localhost:3000"]
```

### Database Connection

The application uses PostgreSQL with async SQLAlchemy. Ensure your `DATABASE_URL` follows this format:

```
postgresql+asyncpg://username:password@host:port/database_name
```

## 🚀 Running the Application

### Local Development

#### Using Uvicorn Directly

```bash
uvicorn src.main:app --reload --host 0.0.0.0 --port 8000
```

#### Using Make Command

```bash
make run
```

#### Using Python Module

```bash
python -m src.main
```

The application will be available at `http://localhost:8000`

### Docker Deployment

#### Build and Run with Docker Compose

```bash
# Start all services (app + PostgreSQL + Prometheus + Grafana)
docker-compose -f docker/docker-compose.yml up -d

# View logs
docker-compose -f docker/docker-compose.yml logs -f app

# Stop services
docker-compose -f docker/docker-compose.yml down
```

#### Build Docker Image Manually

```bash
docker build -f docker/Dockerfile -t fastapi-app:latest .
docker run -p 8000:8000 --env-file .env fastapi-app:latest
```

## 📚 API Documentation

Once the application is running, access the interactive API documentation:

- **Swagger UI**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **ReDoc**: [http://localhost:8000/redoc](http://localhost:8000/redoc)
- **OpenAPI Schema**: [http://localhost:8000/openapi.json](http://localhost:8000/openapi.json)

### Available Endpoints

#### Health Check
```
GET /health/health - System health check
```

#### Products
```
POST   /products              - Create a new product
GET    /products              - List active products (with pagination)
GET    /products/{product_id} - Get product details
PUT    /products/{product_id} - Update product information
PATCH  /products/{product_id}/deactivate - Deactivate a product
```

#### Customers
```
POST   /customers              - Register a new customer
GET    /customers/{customer_id} - Get customer details
```

#### Shopping Cart
```
POST   /carts              - Create a cart (reuses open carts)
GET    /carts/{cart_id}    - Get cart with all items
POST   /carts/{cart_id}/items - Add item to cart
PUT    /carts/{cart_id}/items/{item_id} - Update cart item quantity
DELETE /carts/{cart_id}/items/{item_id} - Remove item from cart
```

#### Orders
```
POST   /orders              - Create an order from cart
GET    /orders/{order_id}   - Get order details
PATCH  /orders/{order_id}/status - Update order status
PATCH  /orders/{order_id}/payment-status - Update payment status
```

#### Metrics
```
GET /metrics - Prometheus metrics endpoint
```

## 🗄️ Database Migrations

### Using Alembic

#### Create a New Migration

```bash
alembic revision --autogenerate -m "Description of changes"
```

#### Apply Migrations

```bash
# Apply all pending migrations
alembic upgrade head

# Apply specific migration
alembic upgrade +1

# Rollback last migration
alembic downgrade -1
```

#### View Migration History

```bash
alembic history
alembic current
```

### Using Makefile

```bash
make migrate          # Run all migrations
make migrate-create   # Create a new migration
make migrate-rollback # Rollback last migration
```

## 🧪 Testing

### Run All Tests

```bash
pytest
```

### Run Tests with Coverage

```bash
pytest --cov=src --cov-report=html
```

### Run Specific Test File

```bash
pytest tests/test_products.py
```

### Run Tests in Watch Mode

```bash
pytest-watch
```

### Using Makefile

```bash
make test           # Run all tests
make test-coverage  # Run tests with coverage report
make test-watch     # Run tests in watch mode
```

### Test Configuration

Tests use a separate PostgreSQL database configured in `docker/docker-compose.test.yml`:

```bash
docker-compose -f docker/docker-compose.test.yml up -d
pytest
docker-compose -f docker/docker-compose.test.yml down
```

## 📁 Project Structure

```
fastapi-application/
├── .env.example                 # Example environment variables
├── .gitignore                   # Git ignore rules
├── Makefile                     # Development commands
├── pyproject.toml               # Project metadata and dependencies
├── requirements.txt             # Python dependencies
├── alembic.ini                  # Alembic configuration
│
├── alembic/                     # Database migrations
│   ├── env.py                   # Migration environment setup
│   ├── script.py.mako           # Migration template
│   └── versions/                # Migration files
│       └── 001_initial.py       # Initial schema migration
│
├── docker/                      # Docker configuration
│   ├── Dockerfile               # Application container
│   ├── docker-compose.yml       # Production compose file
│   ├── docker-compose.test.yml  # Test compose file
│   ├── prometheus.yml           # Prometheus configuration
│   └── grafana/                 # Grafana dashboards
│       ├── dashboards/
│       └── datasources/
│
├── src/                         # Application source code
│   ├── main.py                  # Application entry point
│   ├── config.py                # Configuration management
│   ├── database.py              # Database setup and session
│   │
│   ├── models/                  # SQLAlchemy models
│   │   ├── __init__.py
│   │   ├── product.py
│   │   ├── customer.py
│