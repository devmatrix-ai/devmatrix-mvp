"""
FastAPI Service for Order

Business logic and data access patterns.
"""
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import UUID
import logging

from src.models.schemas import OrderCreate, OrderUpdate, OrderResponse, OrderList
from src.repositories.order_repository import OrderRepository
from src.models.entities import OrderEntity

logger = logging.getLogger(__name__)


class OrderService:
    """Business logic for Order."""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = OrderRepository(db)

    async def create(self, data: OrderCreate) -> OrderResponse:
        """Create a new order."""
        db_obj = await self.repo.create(data)
        return OrderResponse.model_validate(db_obj)

    async def get(self, id: UUID) -> Optional[OrderResponse]:
        """Get order by ID."""
        db_obj = await self.repo.get(id)
        if db_obj:
            return OrderResponse.model_validate(db_obj)
        return None

    async def get_by_id(self, id: UUID) -> Optional[OrderResponse]:
        """Alias for get() to satisfy routes expecting get_by_id."""
        return await self.get(id)

    async def list(self, page: int = 1, size: int = 10) -> OrderList:
        """List orders with pagination."""
        skip = (page - 1) * size

        items = await self.repo.list(skip=skip, limit=size)
        total = await self.repo.count()

        return OrderList(
            items=[OrderResponse.model_validate(t) for t in items],
            total=total,
            page=page,
            size=size,
        )

    async def update(self, id: UUID, data: OrderUpdate) -> Optional[OrderResponse]:
        """Update order."""
        db_obj = await self.repo.update(id, data)
        if db_obj:
            return OrderResponse.model_validate(db_obj)
        return None

    async def delete(self, id: UUID) -> bool:
        """Delete order."""
        return await self.repo.delete(id)

    async def checkout(self, cart_id: UUID) -> OrderResponse:
        """
        Create order from cart with stock validation and decrement.

        PHASE 2: Real enforcement - stock decrement logic (Fase 2.4)

        Steps:
        1. Validate cart exists and is OPEN
        2. Validate cart has items
        3. Validate stock availability for ALL items
        4. Decrement stock for each product
        5. Create order with PENDING_PAYMENT status
        6. Mark cart as CHECKED_OUT
        """
        from src.repositories.cart_repository import CartRepository
        from src.repositories.product_repository import ProductRepository
        from fastapi import HTTPException

        cart_repo = CartRepository(self.db)
        product_repo = ProductRepository(self.db)

        # 1. Get cart and validate
        cart = await cart_repo.get(cart_id)
        if not cart:
            raise HTTPException(status_code=404, detail="Cart not found")

        if cart.status != "OPEN":
            raise HTTPException(status_code=400, detail="Cart is not open for checkout")

        # 2. Validate cart has items
        if not cart.items or len(cart.items) == 0:
            raise HTTPException(status_code=400, detail="Cart is empty")

        # 3. Validate stock for ALL items before decrementing
        for item in cart.items:
            product = await product_repo.get(item.product_id)
            if not product:
                raise HTTPException(status_code=404, detail=f"Product {item.product_id} not found")

            if product.stock < item.quantity:
                raise HTTPException(
                    status_code=422,
                    detail=f"Insufficient stock for product {product.name}: available={product.stock}, requested={item.quantity}"
                )

        # 4. Decrement stock for each product (PHASE 2 - Real enforcement)
        for item in cart.items:
            product = await product_repo.get(item.product_id)
            product.stock -= item.quantity
            await self.db.flush()
            logger.info(f"📦 Stock decremented: {product.name} ({product.stock + item.quantity} → {product.stock})")

        # 5. Create order
        from src.models.schemas import OrderCreate
        order_data = OrderCreate(
            customer_id=cart.customer_id,
            status="PENDING_PAYMENT",
            payment_status="PENDING"
        )
        order = await self.create(order_data)

        # 6. Mark cart as CHECKED_OUT
        cart.status = "CHECKED_OUT"
        await self.db.flush()

        await self.db.commit()

        return order

    async def cancel_order(self, order_id: UUID) -> OrderResponse:
        """
        Cancel order and return stock to products.

        PHASE 2: Real enforcement - stock increment on cancel (Fase 2.4)

        Steps:
        1. Validate order exists and is PENDING_PAYMENT
        2. Increment stock for each product in order
        3. Mark order as CANCELLED
        """
        from src.repositories.product_repository import ProductRepository
        from fastapi import HTTPException

        product_repo = ProductRepository(self.db)

        # 1. Get order and validate
        order = await self.get(order_id)
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")

        if order.status != "PENDING_PAYMENT":
            raise HTTPException(
                status_code=400,
                detail=f"Cannot cancel order with status {order.status}. Only PENDING_PAYMENT orders can be cancelled."
            )

        # 2. Return stock for each product (PHASE 2 - Real enforcement)
        for item in order.items:
            product = await product_repo.get(item.product_id)
            if product:
                product.stock += item.quantity
                await self.db.flush()
                logger.info(f"📦 Stock returned: {product.name} ({product.stock - item.quantity} → {product.stock})")

        # 3. Update order status to CANCELLED
        from src.models.schemas import OrderUpdate
        updated_order = await self.update(
            order_id,
            OrderUpdate(status="CANCELLED")
        )

        await self.db.commit()

        return updated_order