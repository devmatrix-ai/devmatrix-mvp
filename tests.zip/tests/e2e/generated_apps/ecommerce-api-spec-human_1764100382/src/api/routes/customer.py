"""
FastAPI Routes for Customer

Spec-compliant endpoints with:
- Repository pattern integration
- Service layer architecture
- Proper error handling
- Pydantic validation
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from src.core.database import get_db
from src.models.schemas import CustomerCreate, CustomerUpdate, CustomerResponse
from src.services.customer_service import CustomerService
router = APIRouter(prefix='/customers', tags=['customers'])


@router.post('/', response_model=CustomerResponse, status_code=status.
    HTTP_201_CREATED)
async def registrar_nuevo_cliente(customer_data: CustomerCreate, db:
    AsyncSession=Depends(get_db)):
    """
    Registrar nuevo cliente
    """
    service = CustomerService(db)
    customer = await service.create(customer_data)
    return customer


@router.get('/{customer_id}', response_model=CustomerResponse)
async def ver_datos_de_un_cliente_específico(customer_id: str, db:
    AsyncSession=Depends(get_db)):
    """
    Ver datos de un cliente específico
    """
    service = CustomerService(db)
    customer = await service.get_by_id(customer_id)
    if not customer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Customer with id {customer_id} not found')
    return customer


@router.get('/{customer_id}/orders', response_model=CustomerResponse)
async def listar_todas_las_órdenes_de_un_cliente__opcionalmente_filtradas_por_status(
    customer_id: str, db: AsyncSession=Depends(get_db)):
    """
    Listar todas las órdenes de un cliente, opcionalmente filtradas por status
    """
    service = CustomerService(db)
    customer = await service.get_by_id(customer_id)
    if not customer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Customer with id {customer_id} not found')
    return customer


@router.post('/')
async def create_customer(db: AsyncSession=Depends(get_db)):
    pass
