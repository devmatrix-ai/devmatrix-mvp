"""
FastAPI Routes for Order

Spec-compliant endpoints with:
- Repository pattern integration
- Service layer architecture
- Proper error handling
- Pydantic validation
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from src.core.database import get_db
from src.models.schemas import OrderCreate, OrderUpdate, OrderResponse
from src.services.order_service import OrderService
router = APIRouter(prefix='/orders', tags=['orders'])


@router.post('/', response_model=OrderResponse, status_code=status.
    HTTP_201_CREATED)
async def crear_orden_desde_carrito__checkout___valida_stock__resta_inventario__marca_carrito_como_checked_out(
    order_data: OrderCreate, db: AsyncSession=Depends(get_db)):
    """
    Crear orden desde carrito (checkout). Valida stock, resta inventario, marca carrito como CHECKED_OUT
    """
    service = OrderService(db)
    order = await service.create(order_data)
    return order


@router.post('/{order_id}/pay', response_model=OrderResponse, status_code=
    status.HTTP_201_CREATED)
async def marcar_orden_como_pagada__simulado___solo_si_está_en_pending_payment(
    order_id: str, order_data: OrderCreate, db: AsyncSession=Depends(get_db)):
    """
    Marcar orden como pagada (simulado). Solo si está en PENDING_PAYMENT
    """
    service = OrderService(db)
    order = await service.create(order_data)
    return order


@router.post('/{order_id}/cancel', response_model=OrderResponse,
    status_code=status.HTTP_201_CREATED)
async def cancelar_orden_y_devolver_stock__solo_si_está_en_pending_payment(
    order_id: str, order_data: OrderCreate, db: AsyncSession=Depends(get_db)):
    """
    Cancelar orden y devolver stock. Solo si está en PENDING_PAYMENT
    """
    service = OrderService(db)
    order = await service.create(order_data)
    return order


@router.get('/{order_id}', response_model=OrderResponse)
async def ver_detalles_de_una_orden_específica(order_id: str, db:
    AsyncSession=Depends(get_db)):
    """
    Ver detalles de una orden específica
    """
    service = OrderService(db)
    order = await service.get_by_id(order_id)
    if not order:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Order with id {order_id} not found')
    return order


@router.post('/')
async def create_order(db: AsyncSession=Depends(get_db)):
    pass
