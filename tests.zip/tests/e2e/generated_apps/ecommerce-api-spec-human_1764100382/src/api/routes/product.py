"""
FastAPI Routes for Product

Spec-compliant endpoints with:
- Repository pattern integration
- Service layer architecture
- Proper error handling
- Pydantic validation
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from src.core.database import get_db
from src.models.schemas import ProductCreate, ProductUpdate, ProductResponse
from src.services.product_service import ProductService
router = APIRouter(prefix='/products', tags=['products'])


@router.post('/', response_model=ProductResponse, status_code=status.
    HTTP_201_CREATED)
async def crear_nuevo_producto(product_data: ProductCreate, db:
    AsyncSession=Depends(get_db)):
    """
    Crear nuevo producto
    """
    service = ProductService(db)
    product = await service.create(product_data)
    return product


@router.get('/', response_model=List[ProductResponse])
async def listar_productos_activos_con_paginación(db: AsyncSession=Depends(
    get_db)):
    """
    Listar productos activos con paginación
    """
    service = ProductService(db)
    products = await service.get_all(skip=0, limit=100)
    return products


@router.get('/{product_id}', response_model=ProductResponse)
async def ver_detalles_de_un_producto_específico(product_id: str, db:
    AsyncSession=Depends(get_db)):
    """
    Ver detalles de un producto específico
    """
    service = ProductService(db)
    product = await service.get_by_id(product_id)
    if not product:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Product with id {product_id} not found')
    return product


@router.put('/{product_id}', response_model=ProductResponse)
async def actualizar_información_del_producto(product_id: str, product_data:
    ProductCreate, db: AsyncSession=Depends(get_db)):
    """
    Actualizar información del producto
    """
    service = ProductService(db)
    product = await service.update(product_id, product_data)
    if not product:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Product with id {product_id} not found')
    return product


@router.patch('/{product_id}/deactivate', response_model=ProductResponse)
async def desactivar_un_producto__sin_eliminarlo_físicamente_(product_id:
    str, db: AsyncSession=Depends(get_db)):
    """
    Desactivar un producto (sin eliminarlo físicamente)
    """
    service = ProductService(db)


@router.post('/')
async def create_product(db: AsyncSession=Depends(get_db)):
    pass


@router.get('/')
async def get_all_products(db: AsyncSession=Depends(get_db)):
    pass
