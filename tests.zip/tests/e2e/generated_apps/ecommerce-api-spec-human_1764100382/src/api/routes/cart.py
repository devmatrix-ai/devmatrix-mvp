"""
FastAPI Routes for Cart

Spec-compliant endpoints with:
- Repository pattern integration
- Service layer architecture
- Proper error handling
- Pydantic validation
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from src.core.database import get_db
from src.models.schemas import CartCreate, CartUpdate, CartResponse
from src.services.cart_service import CartService
router = APIRouter(prefix='/carts', tags=['carts'])


@router.post('/', response_model=CartResponse, status_code=status.
    HTTP_201_CREATED)
async def crear_carrito_para_un_cliente__si_existe_uno_open__se_reutiliza(
    cart_data: CartCreate, db: AsyncSession=Depends(get_db)):
    """
    Crear carrito para un cliente. Si existe uno OPEN, se reutiliza
    """
    service = CartService(db)
    cart = await service.create(cart_data)
    return cart


@router.get('/{cart_id}', response_model=CartResponse)
async def ver_el_carrito_actual_de_un_cliente_con_todos_los_items(cart_id:
    str, db: AsyncSession=Depends(get_db)):
    """
    Ver el carrito actual de un cliente con todos los items
    """
    service = CartService(db)
    cart = await service.get_by_id(cart_id)
    if not cart:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Cart with id {cart_id} not found')
    return cart


@router.post('/{cart_id}/items', response_model=CartResponse, status_code=
    status.HTTP_201_CREATED)
async def agregar_producto_al_carrito__si_ya_existe__aumenta_cantidad(cart_id:
    str, cart_data: CartCreate, db: AsyncSession=Depends(get_db)):
    """
    Agregar producto al carrito. Si ya existe, aumenta cantidad
    """
    service = CartService(db)
    cart = await service.create(cart_data)
    return cart


@router.put('/{cart_id}/items/{product_id}', response_model=CartResponse)
async def actualizar_cantidad_de_un_ítem_en_el_carrito(cart_id: str,
    product_id: str, cart_data: CartCreate, db: AsyncSession=Depends(get_db)):
    """
    Actualizar cantidad de un ítem en el carrito
    """
    service = CartService(db)
    cart = await service.update(cart_id, cart_data)
    if not cart:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Cart with id {cart_id} not found')
    return cart


@router.delete('/{cart_id}/items/{product_id}', status_code=status.
    HTTP_204_NO_CONTENT)
async def eliminar_un_ítem_del_carrito(cart_id: str, product_id: str, db:
    AsyncSession=Depends(get_db)):
    """
    Eliminar un ítem del carrito
    """
    service = CartService(db)
    success = await service.delete(cart_id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Cart with id {cart_id} not found')
    return None


@router.delete('/{cart_id}', status_code=status.HTTP_204_NO_CONTENT)
async def vaciar_todos_los_items_del_carrito(cart_id: str, db: AsyncSession
    =Depends(get_db)):
    """
    Vaciar todos los items del carrito
    """
    service = CartService(db)
    success = await service.delete(cart_id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=
            f'Cart with id {cart_id} not found')
    return None


@router.post('/')
async def create_cart(db: AsyncSession=Depends(get_db)):
    pass
