"""
Pydantic Request/Response Schemas

Type-safe data validation for API endpoints.
"""
from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime
from uuid import UUID
from typing import List, Optional, Literal
from decimal import Decimal


class BaseSchema(BaseModel):
    """Base schema with UUID-friendly JSON encoding."""
    model_config = ConfigDict(json_encoders={UUID: str}, from_attributes=True)


class CartItem(BaseModel):
    """Item within a cart."""
    product_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: int = Field(..., gt=0)
    unit_price: Decimal = Field(..., gt=0, description=
        'Read-only field (auto-generated)')


class OrderItem(BaseModel):
    """Item within an order."""
    product_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: int = Field(..., gt=0)
    unit_price: Decimal = Field(..., gt=0, description=
        'Read-only field (auto-generated)')


class CartItemBase(BaseSchema):
    """Base schema for cartitem."""
    product_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: int = Field(..., gt=0)
    unit_price: float = Field(..., gt=0)


class CartItemCreate(BaseSchema):
    """Schema for creating cartitem."""
    product_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: int = Field(..., gt=0)
    unit_price: float = Field(..., gt=0)


class CartItemUpdate(BaseSchema):
    """Schema for updating cartitem."""
    product_id: Optional[UUID] = Field(None, pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: Optional[int] = Field(None, gt=0)


class CartItemResponse(CartItemBase):
    """Response schema for cartitem."""
    product_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: int = Field(..., gt=0)
    unit_price: float = Field(..., gt=0)
    id: UUID
    created_at: datetime


class CartItemList(BaseSchema):
    """List response with pagination."""
    items: List[CartItemResponse]
    total: int
    page: int


class OrderItemBase(BaseSchema):
    """Base schema for orderitem."""
    product_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: int = Field(..., gt=0)
    unit_price: float = Field(..., gt=0)


class OrderItemCreate(BaseSchema):
    """Schema for creating orderitem."""
    product_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: int = Field(..., gt=0)
    unit_price: float = Field(..., gt=0)


class OrderItemUpdate(BaseSchema):
    """Schema for updating orderitem."""
    product_id: Optional[UUID] = Field(None, pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: Optional[int] = Field(None, gt=0)


class OrderItemResponse(OrderItemBase):
    """Response schema for orderitem."""
    product_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    quantity: int = Field(..., gt=0)
    unit_price: float = Field(..., gt=0)
    id: UUID
    created_at: datetime


class OrderItemList(BaseSchema):
    """List response with pagination."""
    items: List[OrderItemResponse]
    total: int
    page: int


class ProductBase(BaseSchema):
    """Base schema for product."""
    name: str = Field(..., max_length=255, min_length=1)
    description: Optional[str] = Field(None, max_length=1000)
    price: float = Field(..., gt=0)
    stock: int = Field(..., ge=0)
    is_active: bool


class ProductCreate(BaseSchema):
    """Schema for creating product."""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    price: float = Field(..., gt=0)
    stock: int = Field(..., ge=0)
    is_active: bool


class ProductUpdate(BaseSchema):
    """Schema for updating product."""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    price: Optional[float] = Field(None, gt=0)
    stock: Optional[int] = Field(None, ge=0)
    is_active: Optional[bool] = None


class ProductResponse(ProductBase):
    """Response schema for product."""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    price: float = Field(..., gt=0)
    stock: int = Field(..., ge=0)
    is_active: bool
    id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')


class ProductList(BaseSchema):
    """List response with pagination."""
    items: List[ProductResponse]
    total: int
    page: int


class CustomerBase(BaseSchema):
    """Base schema for customer."""
    email: str = Field(..., max_length=255, pattern='^[^@]+@[^@]+\\.[^@]+$')
    full_name: str = Field(..., max_length=255, min_length=1)
    registration_date: datetime = Field(description=
        'Read-only field (auto-generated)')


class CustomerCreate(BaseSchema):
    """Schema for creating customer."""
    email: str = Field(..., pattern='^[^@]+@[^@]+\\.[^@]+$', max_length=255)
    full_name: str = Field(..., min_length=1, max_length=255)


class CustomerUpdate(BaseSchema):
    """Schema for updating customer."""
    email: Optional[str] = Field(None, pattern='^[^@]+@[^@]+\\.[^@]+$',
        max_length=255)
    full_name: Optional[str] = Field(None, min_length=1, max_length=255)


class CustomerResponse(CustomerBase):
    """Response schema for customer."""
    email: str = Field(..., pattern='^[^@]+@[^@]+\\.[^@]+$', max_length=255)
    full_name: str = Field(..., min_length=1, max_length=255)
    registration_date: datetime
    id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')


class CustomerList(BaseSchema):
    """List response with pagination."""
    items: List[CustomerResponse]
    total: int
    page: int


class CartBase(BaseSchema):
    """Base schema for cart."""
    customer_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    status: Literal['open', 'checked_out'] = 'OPEN'
    items: List[CartItem]


class CartCreate(BaseSchema):
    """Schema for creating cart."""
    customer_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    status: Literal['OPEN', 'CHECKED_OUT'] = 'OPEN'
    items: List[CartItem]


class CartUpdate(BaseSchema):
    """Schema for updating cart."""
    customer_id: Optional[UUID] = Field(None, pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    status: Optional[Literal['OPEN', 'CHECKED_OUT']] = None
    items: Optional[List[CartItem]] = None


class CartResponse(CartBase):
    """Response schema for cart."""
    customer_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    status: Literal['OPEN', 'CHECKED_OUT'] = 'OPEN'
    items: List[CartItem]
    id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')


class CartList(BaseSchema):
    """List response with pagination."""
    items: List[CartResponse]
    total: int
    page: int


class OrderBase(BaseSchema):
    """Base schema for order."""
    customer_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    order_status: Literal['pending_payment', 'paid', 'cancelled'] = Field(...,
        min_length=1, max_length=255)
    payment_status: Literal['pending', 'simulated_ok', 'failed'] = 'PENDING'
    total_amount: float = Field(..., ge=0, description=
        'Auto-calculated: auto-calculated')
    items: List[OrderItem]
    creation_date: datetime = Field(description=
        'Read-only field (auto-generated)')


class OrderCreate(BaseSchema):
    """Schema for creating order."""
    customer_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    order_status: str = Field(..., min_length=1, max_length=255)
    payment_status: Literal['PENDING', 'SIMULATED_OK', 'FAILED'] = 'PENDING'
    items: List[OrderItem]


class OrderUpdate(BaseSchema):
    """Schema for updating order."""
    customer_id: Optional[UUID] = Field(None, pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    order_status: Optional[str] = Field(None, min_length=1, max_length=255)
    payment_status: Optional[Literal['PENDING', 'SIMULATED_OK', 'FAILED']
        ] = None
    items: Optional[List[OrderItem]] = None


class OrderResponse(OrderBase):
    """Response schema for order."""
    customer_id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    order_status: str = Field(..., min_length=1, max_length=255)
    payment_status: Literal['PENDING', 'SIMULATED_OK', 'FAILED'] = 'PENDING'
    total_amount: float = Field(..., ge=0)
    items: List[OrderItem]
    creation_date: datetime
    id: UUID = Field(..., pattern=
        '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')


class OrderList(BaseSchema):
    """List response with pagination."""
    items: List[OrderResponse]
    total: int
    page: int
