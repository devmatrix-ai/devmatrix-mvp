"""
Unit Tests for Services

Tests for business logic, HTML sanitization, and entity-schema conversion.
Coverage target: 80%+ for services/
"""
import pytest
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4
{% for entity in entities %}
from src.services.{{ entity.snake_name }}_service import {{ entity.name }}Service
from src.repositories.{{ entity.snake_name }}_repository import {{ entity.name }}Repository
from src.models.entities import {{ entity.name }}Entity
from tests.factories import {{ entity.name }}Factory
{% endfor %}

{% for entity in entities %}
class Test{{ entity.name }}Service:
    """Tests for {{ entity.name }}Service business logic."""

    @pytest.mark.asyncio
    async def test_create_{{ entity.snake_name }}_success(self):
        """Test creating {{ entity.snake_name }} through service."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        {{ entity.snake_name }}_data = {{ entity.name }}Factory.create()
        mock_entity = {{ entity.name }}Entity(
            id=uuid4(),
            **{{ entity.snake_name }}_data.model_dump(),
        )
        mock_repo.create.return_value = mock_entity

        result = await service.create_{{ entity.snake_name }}({{ entity.snake_name }}_data)

        assert result.id == mock_entity.id
        mock_repo.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_{{ entity.snake_name }}_sanitizes_html(self):
        """Test HTML sanitization during {{ entity.snake_name }} creation."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        {{ entity.snake_name }}_data = {{ entity.name }}Factory.create(
            {% for field in entity.fields %}
            {% if field.type == "str" and field.name not in ['id', 'email'] and not field.primary_key %}
            {{ field.name }}="<script>alert('xss')</script>Safe Content",
            
            {% endif %}
            {% endfor %}
        )

        mock_entity = {{ entity.name }}Entity(
            id=uuid4(),
            **{{ entity.snake_name }}_data.model_dump(),
        )
        mock_repo.create.return_value = mock_entity

        await service.create_{{ entity.snake_name }}({{ entity.snake_name }}_data)

        # Verify sanitize_html was called by checking that script tags are removed
        {% for field in entity.fields %}
        {% if field.type == "str" and field.name not in ['id', 'email'] and not field.primary_key %}
        call_args = mock_repo.create.call_args[0][0]
        assert "<script>" not in call_args.{{ field.name }}
        assert "Safe Content" in call_args.{{ field.name }}
        
        {% endif %}
        {% endfor %}

    @pytest.mark.asyncio
    async def test_get_existing_{{ entity.snake_name }}(self):
        """Test getting existing {{ entity.snake_name }} returns schema."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        {{ entity.snake_name }}_id = uuid4()
        mock_entity = {{ entity.name }}Entity(
            id={{ entity.snake_name }}_id,
            **{{ entity.name }}Factory.create().model_dump(),
        )
        mock_repo.get.return_value = mock_entity

        result = await service.get_{{ entity.snake_name }}({{ entity.snake_name }}_id)

        assert result is not None
        assert result.id == {{ entity.snake_name }}_id
        mock_repo.get.assert_called_once_with({{ entity.snake_name }}_id)

    @pytest.mark.asyncio
    async def test_get_nonexistent_{{ entity.snake_name }}(self):
        """Test getting nonexistent {{ entity.snake_name }} returns None."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        mock_repo.get.return_value = None

        result = await service.get_{{ entity.snake_name }}(uuid4())

        assert result is None

    @pytest.mark.asyncio
    async def test_list_{{ entity.table_name }}_with_pagination(self):
        """Test listing {{ entity.table_name }} with pagination."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        # Create 3 mock entities
        mock_entities = [
            {{ entity.name }}Entity(id=uuid4(), **{{ entity.name }}Factory.create().model_dump())
            for _ in range(3)
        ]
        mock_repo.list.return_value = mock_entities
        mock_repo.count.return_value = 10

        result = await service.list_{{ entity.table_name }}(page=1, size=3)

        assert len(result.items) == 3
        assert result.total == 10
        assert result.page == 1
        assert result.size == 3
        assert result.pages == 4  # ceil(10/3) = 4
        mock_repo.list.assert_called_once_with(skip=0, limit=3)

    @pytest.mark.asyncio
    async def test_list_{{ entity.table_name }}_pagination_calculation(self):
        """Test pagination calculation for different scenarios."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        mock_repo.list.return_value = []
        mock_repo.count.return_value = 25

        result = await service.list_{{ entity.table_name }}(page=2, size=10)

        assert result.page == 2
        assert result.size == 10
        assert result.pages == 3  # ceil(25/10) = 3
        mock_repo.list.assert_called_once_with(skip=10, limit=10)

    @pytest.mark.asyncio
    async def test_update_existing_{{ entity.snake_name }}(self):
        """Test updating existing {{ entity.snake_name }}."""
        from src.models.schemas import {{ entity.name }}Update

        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        {{ entity.snake_name }}_id = uuid4()
        update_data = {{ entity.name }}Update(
            {% for field in entity.fields %}
            {% if not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
            {% if field.type == "str" %}
            {{ field.name }}="updated_value"
            
            {% endif %}
            {% endif %}
            {% endfor %}
        )

        updated_entity = {{ entity.name }}Entity(
            id={{ entity.snake_name }}_id,
            **{{ entity.name }}Factory.create().model_dump(),
        )
        mock_repo.update.return_value = updated_entity

        result = await service.update_{{ entity.snake_name }}({{ entity.snake_name }}_id, update_data)

        assert result is not None
        assert result.id == {{ entity.snake_name }}_id
        mock_repo.update.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_{{ entity.snake_name }}_sanitizes_html(self):
        """Test HTML sanitization during {{ entity.snake_name }} update."""
        from src.models.schemas import {{ entity.name }}Update

        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        {{ entity.snake_name }}_id = uuid4()
        update_data = {{ entity.name }}Update(
            {% for field in entity.fields %}
            {% if field.type == "str" and field.name not in ['id', 'email'] and not field.primary_key %}
            {{ field.name }}="<img src=x onerror=alert('xss')>Safe Content"
            
            {% endif %}
            {% endfor %}
        )

        updated_entity = {{ entity.name }}Entity(
            id={{ entity.snake_name }}_id,
            **{{ entity.name }}Factory.create().model_dump(),
        )
        mock_repo.update.return_value = updated_entity

        await service.update_{{ entity.snake_name }}({{ entity.snake_name }}_id, update_data)

        # Verify sanitize_html was called
        {% for field in entity.fields %}
        {% if field.type == "str" and field.name not in ['id', 'email'] and not field.primary_key %}
        call_args = mock_repo.update.call_args[0][1]
        assert "<img" not in call_args.{{ field.name }}
        assert "Safe Content" in call_args.{{ field.name }}
        
        {% endif %}
        {% endfor %}

    @pytest.mark.asyncio
    async def test_update_nonexistent_{{ entity.snake_name }}(self):
        """Test updating nonexistent {{ entity.snake_name }} returns None."""
        from src.models.schemas import {{ entity.name }}Update

        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        mock_repo.update.return_value = None

        result = await service.update_{{ entity.snake_name }}(
            uuid4(),
            {{ entity.name }}Update()
        )

        assert result is None

    @pytest.mark.asyncio
    async def test_delete_existing_{{ entity.snake_name }}(self):
        """Test deleting existing {{ entity.snake_name }}."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        mock_repo.delete.return_value = True

        result = await service.delete_{{ entity.snake_name }}(uuid4())

        assert result is True

    @pytest.mark.asyncio
    async def test_delete_nonexistent_{{ entity.snake_name }}(self):
        """Test deleting nonexistent {{ entity.snake_name }}."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        mock_repo.delete.return_value = False

        result = await service.delete_{{ entity.snake_name }}(uuid4())

        assert result is False

    @pytest.mark.asyncio
    async def test_entity_to_schema_conversion(self):
        """Test entity-to-schema conversion preserves all fields."""
        mock_repo = AsyncMock(spec={{ entity.name }}Repository)
        service = {{ entity.name }}Service(mock_repo)

        {{ entity.snake_name }}_data = {{ entity.name }}Factory.create()
        mock_entity = {{ entity.name }}Entity(
            id=uuid4(),
            **{{ entity.snake_name }}_data.model_dump(),
        )
        mock_repo.get.return_value = mock_entity

        result = await service.get_{{ entity.snake_name }}(mock_entity.id)

        # Verify all fields are correctly converted
        assert result.id == mock_entity.id
        {% for field in entity.fields %}
        {% if not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
        assert result.{{ field.name }} == mock_entity.{{ field.name }}
        {% endif %}
        {% endfor %}
        assert result.created_at == mock_entity.created_at
        assert result.updated_at == mock_entity.updated_at

{% endfor %}