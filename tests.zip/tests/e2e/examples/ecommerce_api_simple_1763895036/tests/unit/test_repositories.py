"""
Unit Tests for Repositories

Tests for CRUD operations and database interactions.
Coverage target: 85%+ for repositories/
"""
import pytest
from uuid import uuid4
from sqlalchemy.ext.asyncio import AsyncSession
{% for entity in entities %}
from src.repositories.{{ entity.snake_name }}_repository import {{ entity.name }}Repository
from tests.factories import {{ entity.name }}Factory
{% endfor %}


{% for entity in entities %}
class Test{{ entity.name }}Repository:
    """Tests for {{ entity.name }}Repository CRUD operations."""

    @pytest.mark.asyncio
    async def test_create_{{ entity.snake_name }}(self, db_session: AsyncSession):
        """Test creating a new {{ entity.snake_name }}."""
        repo = {{ entity.name }}Repository(db_session)
        {{ entity.snake_name }}_data = {{ entity.name }}Factory.create()

        result = await repo.create({{ entity.snake_name }}_data)

        assert result.id is not None
        {% for field in entity.fields %}
        {% if not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
        assert result.{{ field.name }} == {{ entity.snake_name }}_data.{{ field.name }}
        {% endif %}
        {% endfor %}
        assert result.created_at is not None
        assert result.updated_at is not None

    @pytest.mark.asyncio
    async def test_get_existing_{{ entity.snake_name }}(self, db_session: AsyncSession):
        """Test getting an existing {{ entity.snake_name }} by ID."""
        repo = {{ entity.name }}Repository(db_session)
        {{ entity.snake_name }}_data = {{ entity.name }}Factory.create()
        created = await repo.create({{ entity.snake_name }}_data)

        result = await repo.get(created.id)

        assert result is not None
        assert result.id == created.id
        {% for field in entity.fields %}
        {% if not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
        assert result.{{ field.name }} == created.{{ field.name }}
        {% endif %}
        {% endfor %}

    @pytest.mark.asyncio
    async def test_get_nonexistent_{{ entity.snake_name }}(self, db_session: AsyncSession):
        """Test getting a {{ entity.snake_name }} that doesn't exist."""
        repo = {{ entity.name }}Repository(db_session)
        fake_id = uuid4()

        result = await repo.get(fake_id)

        assert result is None

    @pytest.mark.asyncio
    async def test_list_{{ entity.table_name }}_empty(self, db_session: AsyncSession):
        """Test listing {{ entity.table_name }} when database is empty."""
        repo = {{ entity.name }}Repository(db_session)

        result = await repo.list()

        assert result == []

    @pytest.mark.asyncio
    async def test_list_{{ entity.table_name }}_with_data(self, db_session: AsyncSession):
        """Test listing {{ entity.table_name }} with data."""
        repo = {{ entity.name }}Repository(db_session)

        # Create 3 {{ entity.table_name }}
        for _ in range(3):
            await repo.create({{ entity.name }}Factory.create())

        result = await repo.list()

        assert len(result) == 3

    @pytest.mark.asyncio
    async def test_list_{{ entity.table_name }}_pagination(self, db_session: AsyncSession):
        """Test pagination in list operation."""
        repo = {{ entity.name }}Repository(db_session)

        # Create 5 {{ entity.table_name }}
        for _ in range(5):
            await repo.create({{ entity.name }}Factory.create())

        # Get page 2 with size 2
        result = await repo.list(skip=2, limit=2)

        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_count_{{ entity.table_name }}(self, db_session: AsyncSession):
        """Test counting total {{ entity.table_name }}."""
        repo = {{ entity.name }}Repository(db_session)

        # Create 3 {{ entity.table_name }}
        for _ in range(3):
            await repo.create({{ entity.name }}Factory.create())

        result = await repo.count()

        assert result == 3

    @pytest.mark.asyncio
    async def test_update_existing_{{ entity.snake_name }}(self, db_session: AsyncSession):
        """Test updating an existing {{ entity.snake_name }}."""
        from src.models.schemas import {{ entity.name }}Update

        repo = {{ entity.name }}Repository(db_session)
        {{ entity.snake_name }}_data = {{ entity.name }}Factory.create()
        created = await repo.create({{ entity.snake_name }}_data)

        # Update {{ entity.snake_name }}
        update_data = {{ entity.name }}Update(
            {%% set found = namespace(value=False) %%}
            {% for field in entity.fields %}
            {% if not found.value and not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
            {% if field.type == "str" %}
            {{ field.name }}="updated_{{ field.name }}",
            {% set found.value = True %}
            {% endif %}
            {% endif %}
            {% endfor %}
        )
        result = await repo.update(created.id, update_data)

        assert result is not None
        assert result.id == created.id
        {%% set found = namespace(value=False) %%}
        {% for field in entity.fields %}
        {% if not found.value and not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
        {% if field.type == "str" %}
        assert result.{{ field.name }} == "updated_{{ field.name }}"
        {% set found.value = True %}
        {% endif %}
        {% endif %}
        {% endfor %}

    @pytest.mark.asyncio
    async def test_update_nonexistent_{{ entity.snake_name }}(self, db_session: AsyncSession):
        """Test updating a {{ entity.snake_name }} that doesn't exist."""
        from src.models.schemas import {{ entity.name }}Update

        repo = {{ entity.name }}Repository(db_session)
        fake_id = uuid4()
        update_data = {{ entity.name }}Update(
            {%% set found = namespace(value=False) %%}
            {% for field in entity.fields %}
            {% if not found.value and not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
            {% if field.type == "str" %}
            {{ field.name }}="updated_{{ field.name }}",
            {% set found.value = True %}
            {% endif %}
            {% endif %}
            {% endfor %}
        )

        result = await repo.update(fake_id, update_data)

        assert result is None

    @pytest.mark.asyncio
    async def test_update_partial_fields(self, db_session: AsyncSession):
        """Test updating only some fields of {{ entity.snake_name }}."""
        from src.models.schemas import {{ entity.name }}Update

        repo = {{ entity.name }}Repository(db_session)
        {{ entity.snake_name }}_data = {{ entity.name }}Factory.create()
        created = await repo.create({{ entity.snake_name }}_data)

        # Store original value
        {% for field in entity.fields %}
        {% if not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
        original_{{ field.name }} = created.{{ field.name }}
        {% endif %}
        {% endfor %}

        # Update only one field
        update_data = {{ entity.name }}Update(
            {%% set found = namespace(value=False) %%}
            {% for field in entity.fields %}
            {% if not found.value and not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
            {% if field.type == "str" %}
            {{ field.name }}="updated_value"
            {% set found.value = True %}
            {% endif %}
            {% endif %}
            {% endfor %}
        )
        result = await repo.update(created.id, update_data)

        # Updated field should change
        {%% set found = namespace(value=False) %%}
        {% for field in entity.fields %}
        {% if not found.value and not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
        {% if field.type == "str" %}
        assert result.{{ field.name }} == "updated_value"
        {% set found.value = True %}
        {% endif %}
        {% endif %}
        {% endfor %}

        # Other fields should remain unchanged
        {% set updated_field_found = namespace(value=False) %}
        {% for field in entity.fields %}
        {% if not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
        {% if not updated_field_found.value %}
        {% if field.type == "str" %}
        {% set updated_field_found.value = True %}
        {% endif %}
        {% else %}
        assert result.{{ field.name }} == original_{{ field.name }}
        {% endif %}
        {% endif %}
        {% endfor %}

    @pytest.mark.asyncio
    async def test_delete_existing_{{ entity.snake_name }}(self, db_session: AsyncSession):
        """Test deleting an existing {{ entity.snake_name }}."""
        repo = {{ entity.name }}Repository(db_session)
        {{ entity.snake_name }}_data = {{ entity.name }}Factory.create()
        created = await repo.create({{ entity.snake_name }}_data)

        result = await repo.delete(created.id)

        assert result is True

        # Verify it's actually deleted
        deleted = await repo.get(created.id)
        assert deleted is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent_{{ entity.snake_name }}(self, db_session: AsyncSession):
        """Test deleting a {{ entity.snake_name }} that doesn't exist."""
        repo = {{ entity.name }}Repository(db_session)
        fake_id = uuid4()

        result = await repo.delete(fake_id)

        assert result is False


{% endfor %}