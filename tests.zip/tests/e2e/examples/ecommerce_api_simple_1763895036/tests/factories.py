"""
Test Data Factories

Factory classes for creating test data with realistic defaults.
"""
from datetime import datetime, timezone
from uuid import uuid4
from typing import Dict, Any, List
{% for entity in entities %}
from src.models.schemas import {{ entity.name }}Create
{% endfor %}


{% for entity in entities %}
class {{ entity.name }}Factory:
    """Factory for creating {{ entity.name }} test data."""

    @staticmethod
    def create(**kwargs: Any) -> {{ entity.name }}Create:
        """
        Create {{ entity.name }}Create schema with realistic defaults.

        Args:
            **kwargs: Override default values

        Returns:
            {{ entity.name }}Create schema
        """
        defaults: Dict[str, Any] = {
            {% for field in entity.fields %}
            {% if not field.primary_key and field.name not in ['created_at', 'updated_at'] %}
            {% if field.type == "str" %}
            "{{ field.name }}": "{{ field.name }}_{{ '{' }}{{ uuid4().hex[:8] }}{{ '}' }}",
            {% elif field.type == "bool" %}
            "{{ field.name }}": {% if field.default %}{{ field.default }}{% else %}False{% endif %},
            {% elif field.type == "int" %}
            "{{ field.name }}": {% if field.default %}{{ field.default }}{% else %}0{% endif %},
            {% elif field.type == "Decimal" %}
            "{{ field.name }}": {% if field.default %}{{ field.default }}{% else %}99.99{% endif %},
            {% elif field.type == "datetime" %}
            "{{ field.name }}": datetime.now(timezone.utc),
            {% endif %}
            {% endif %}
            {% endfor %}
        }
        defaults.update(kwargs)
        return {{ entity.name }}Create(**defaults)

    @staticmethod
    def create_batch(n: int, **kwargs: Any) -> List[{{ entity.name }}Create]:
        """
        Create multiple {{ entity.name }}Create schemas.

        Args:
            n: Number of instances to create
            **kwargs: Override default values for all instances

        Returns:
            List of {{ entity.name }}Create schemas
        """
        return [{{ entity.name }}Factory.create(**kwargs) for _ in range(n)]


{% endfor %}