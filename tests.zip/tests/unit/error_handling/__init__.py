"""Tests for error handling module."""
