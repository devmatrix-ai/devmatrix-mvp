"""RAG module tests."""
