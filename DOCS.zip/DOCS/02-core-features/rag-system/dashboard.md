# RAG Dashboard

Generated: 2025-11-03T13:04:08.275595 UTC

## Collections

| Collection | Description | Count | Embedding | Dim |
|-----------:|------------|------:|----------|----:|
| `devmatrix_curated` | Curated Patterns | 52 | jinaai/jina-embeddings-v2-base-code | 768 |
| `devmatrix_project_code` | Project Code | 1735 | jinaai/jina-embeddings-v2-base-code | 768 |
| `devmatrix_standards` | Standards & Guidelines | 10 | jinaai/jina-embeddings-v2-base-code | 768 |

**Total examples across collections:** 1797